#include "gridInit.h"

GridInit::GridInit() {}
	
GridInit::~GridInit() {}
