### CS 246 Group Project

[![build status](https://git.uwaterloo.ca/actomala/cs246-project/badges/master/build.svg)](https://git.uwaterloo.ca/actomala/cs246-project/commits/master)
