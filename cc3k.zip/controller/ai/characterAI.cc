#include "characterAI.h"

CharacterAI::CharacterAI(std::shared_ptr<Game> theGame): mGame {theGame} { }

CharacterAI::~CharacterAI() { }
