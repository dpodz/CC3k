#include <memory>
#include "controller.h"
#include "../model/entity/character.h"
#include "../model/game.h"

using namespace std;

Controller::Controller() { }

Controller::~Controller() { }
