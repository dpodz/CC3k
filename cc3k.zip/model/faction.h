#ifndef FACTION_H
#define FACTION_H

typedef int FactionId;

enum class FactionRelation {
	hostile,
	neutral,
	friendly
};

#endif // FACTION_H
