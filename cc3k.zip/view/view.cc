#include "view.h"

View::View(): Observer {} {}
	
View::~View() {}

